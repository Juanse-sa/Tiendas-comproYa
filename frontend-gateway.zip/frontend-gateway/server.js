// server.js (ESM)
import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import morgan from "morgan";
import cors from "cors";
import { createProxyMiddleware } from "http-proxy-middleware";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(morgan("dev"));
app.use(cors());
app.use(express.json());

// ====== Targets (pon tus URLs de Cloud Run) ======
const AUTH_URL   = process.env.AUTH_URL   || "https://auth-service-942623223069.us-central1.run.app";
const CATALOG_URL= process.env.CATALOG_URL|| "https://catalogo-service-942623223069.us-central1.run.app";
const WALLET_URL = process.env.WALLET_URL || "https://wallet-service-942623223069.us-central1.run.app";

// ====== Proxies ======
// /api/auth -> AUTH_URL/
app.use("/api/auth", createProxyMiddleware({
  target: AUTH_URL,
  changeOrigin: true,
  pathRewrite: { "^/api/auth": "/" },
}));

// /api/catalog -> CATALOG_URL/
app.use("/api/catalog", createProxyMiddleware({
  target: CATALOG_URL,
  changeOrigin: true,
  pathRewrite: { "^/api/catalog": "/" },
}));

// /api/wallet -> WALLET_URL/
app.use("/api/wallet", createProxyMiddleware({
  target: WALLET_URL,
  changeOrigin: true,
  pathRewrite: { "^/api/wallet": "/" },
}));

// ====== Estáticos ======
app.use(express.static(path.join(__dirname, "public")));

// SPA fallback
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Healthcheck opcional
app.get("/_ah/health", (_req, res) => res.status(200).send("ok"));

const PORT = process.env.PORT || 8080;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🧩 frontend-gateway en :${PORT}`);
  console.log(`AUTH_URL=${AUTH_URL}`);
  console.log(`CATALOG_URL=${CATALOG_URL}`);
  console.log(`WALLET_URL=${WALLET_URL}`);
});
