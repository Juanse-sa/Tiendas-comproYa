# Frontend Gateway - ComproYa

Sirve el frontend estático y proxy a microservicios bajo `/api/*` para evitar CORS.

## Variables de entorno (Cloud Run)
- AUTH_URL: URL base del servicio de auth (https://...run.app)
- CATALOG_URL: URL base del servicio de catálogo
- WALLET_URL: URL base del servicio de wallet

## Local
```bash
npm ci
npm start
# abre http://localhost:8080
```
